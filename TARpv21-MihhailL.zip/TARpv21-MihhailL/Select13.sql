select * from Person
select top 3 Age, Name from Person