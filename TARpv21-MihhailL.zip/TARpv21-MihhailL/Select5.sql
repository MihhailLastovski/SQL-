select * from Person where City like 'n%'
select * from Person where Email like '%@%'