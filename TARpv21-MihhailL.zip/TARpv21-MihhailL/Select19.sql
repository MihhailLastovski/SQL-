alter table Person
alter column Name nvarchar(30)