select * from Person where (City = 'Gotham' or City = 'Los Angeles')
and Age >= 40