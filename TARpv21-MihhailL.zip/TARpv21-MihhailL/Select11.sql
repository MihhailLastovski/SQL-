select * from Person order by Name
select * from Person order by Name desc