select * from Person order by cast(Age as int)
select * from Person order by Age