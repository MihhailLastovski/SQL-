select * from Person where City <> 'Gotham'
select * from Person where City != 'Gotham'